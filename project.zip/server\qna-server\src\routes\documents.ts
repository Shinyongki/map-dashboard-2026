import { Router, Request, Response } from "express";
import multer from "multer";
import { authenticateToken, requireAdmin } from "./auth";
import { getDb, getBucket, isFirebaseConfigured } from "../firebase";
import { extractTextFromPDF } from "../services/pdf";
import type { OfficialDocument } from "../types";

const router = Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });

// ── Mock data (shared with questions route for consistency) ──
let mockDocuments: OfficialDocument[] = [
  {
    id: "doc1",
    title: "2026년 노인돌봄서비스 사업안내",
    documentNumber: "경남복지-2026-001",
    content:
      "2026년 노인돌봄서비스 사업안내입니다. 주요 변경사항: 1) 서비스 대상자 확대 - 기존 65세 이상에서 60세 이상으로 확대. 2) 서비스 단가 인상 - 시간당 15,000원에서 17,000원으로 조정. 3) 종사자 처우개선 - 월 기본급 5% 인상. 4) 신규 프로그램 도입 - AI 기반 건강모니터링 서비스 시범 운영.",
    fileUrl: "",
    uploadedAt: null as any,
    uploadedBy: "admin",
  },
  {
    id: "doc2",
    title: "긴급복지지원 업무처리 지침 개정",
    documentNumber: "경남복지-2026-015",
    content:
      "긴급복지지원 업무처리 지침 개정사항을 안내합니다. 1) 위기사유 판단기준 완화 - 소득기준 중위소득 75%에서 85%로 상향. 2) 지원기간 연장 - 최대 6개월에서 9개월로 연장 가능. 3) 현물지원 품목 확대. 4) 긴급복지 핫라인 24시간 운영 의무화.",
    fileUrl: "",
    uploadedAt: null as any,
    uploadedBy: "admin",
  },
];
let mockDocIdCounter = 10;

// GET /api/documents
router.get("/", authenticateToken, async (req: Request, res: Response) => {
  try {
    if (!isFirebaseConfigured()) {
      res.json(mockDocuments);
      return;
    }

    const snapshot = await getDb()
      .collection("documents")
      .orderBy("uploadedAt", "desc")
      .get();
    const docs = snapshot.docs.map(
      (d) => ({ id: d.id, ...d.data() }) as OfficialDocument
    );
    res.json(docs);
  } catch (err) {
    console.error("문서 목록 조회 실패:", err);
    res.status(500).json({ error: "문서 목록을 불러올 수 없습니다." });
  }
});

// POST /api/documents (multipart upload)
router.post(
  "/",
  authenticateToken,
  requireAdmin,
  upload.single("file"),
  async (req: Request, res: Response) => {
    try {
      const { title, documentNumber, content: manualContent } = req.body;
      const file = req.file;

      if (!file || !title || !documentNumber) {
        res
          .status(400)
          .json({ error: "파일, 제목, 공문번호를 모두 입력해주세요." });
        return;
      }

      const user = (req as any).user;
      let content = manualContent || "";

      // Extract text from PDF if no manual content
      if (!content && file.mimetype === "application/pdf") {
        content = await extractTextFromPDF(file.buffer);
      }

      if (!isFirebaseConfigured()) {
        const id = `doc${++mockDocIdCounter}`;
        mockDocuments.push({
          id,
          title,
          documentNumber,
          content,
          fileUrl: "",
          uploadedAt: null as any,
          uploadedBy: user.name,
        });
        res.status(201).json({ id });
        return;
      }

      // Upload file to Firebase Storage
      const bucket = getBucket();
      const fileName = `documents/${Date.now()}_${file.originalname}`;
      const fileRef = bucket.file(fileName);
      await fileRef.save(file.buffer, {
        metadata: { contentType: file.mimetype },
      });
      const [fileUrl] = await fileRef.getSignedUrl({
        action: "read",
        expires: "2030-01-01",
      });

      const docRef = await getDb().collection("documents").add({
        title,
        documentNumber,
        content,
        fileUrl,
        uploadedAt:
          require("firebase-admin").firestore.FieldValue.serverTimestamp(),
        uploadedBy: user.name,
      });

      res.status(201).json({ id: docRef.id });
    } catch (err) {
      console.error("문서 업로드 실패:", err);
      res.status(500).json({ error: "문서를 업로드할 수 없습니다." });
    }
  }
);

// DELETE /api/documents/:id
router.delete(
  "/:id",
  authenticateToken,
  requireAdmin,
  async (req: Request, res: Response) => {
    try {
      const id = req.params.id as string;

      if (!isFirebaseConfigured()) {
        mockDocuments = mockDocuments.filter((d) => d.id !== id);
        res.json({ success: true });
        return;
      }

      const docSnap = await getDb().collection("documents").doc(id).get();
      if (docSnap.exists) {
        const data = docSnap.data() as OfficialDocument;
        if (data.fileUrl) {
          try {
            const bucket = getBucket();
            const fileName = data.fileUrl.split("/").pop()?.split("?")[0];
            if (fileName) {
              await bucket.file(`documents/${fileName}`).delete();
            }
          } catch {
            // file may not exist
          }
        }
      }
      await getDb().collection("documents").doc(id).delete();

      res.json({ success: true });
    } catch (err) {
      console.error("문서 삭제 실패:", err);
      res.status(500).json({ error: "문서를 삭제할 수 없습니다." });
    }
  }
);

export default router;
