
import { useEffect, useRef, useState } from 'react';

interface WelfareFacility {
    name: string;
    address: string;
    phone: string;
    mainContact?: string;
    region?: string;
    category: string;
    group: string;
    lat?: number;
    lng?: number;
}

// Category Groups Definition
const CATEGORY_GROUPS = [
    {
        id: "public",
        label: "공공·행정",
        categories: ["시군구청", "소방서", "경찰서", "보건소", "행정복지센터", "응급안전"],
        color: "#ef4444" // Red-ish
    },
    {
        id: "specialized",
        label: "전문·보호",
        categories: ["정신건강", "노인보호", "의료기관"],
        color: "#f59e0b" // Amber/Orange
    },
    {
        id: "community",
        label: "지역사회복지",
        categories: ["종합복지관", "노인복지관", "장애인복지관", "자원봉사"],
        color: "#10b981" // Green
    },
    {
        id: "performer",
        label: "수행기관",
        categories: ["수행기관"],
        color: "#3b82f6" // Blue
    }
];

export default function WelfareMap() {
    const mapContainer = useRef<HTMLDivElement>(null);
    const [mapInstance, setMapInstance] = useState<any>(null);
    const [facilities, setFacilities] = useState<WelfareFacility[]>([]);
    const [filteredFacilities, setFilteredFacilities] = useState<WelfareFacility[]>([]);
    const [loading, setLoading] = useState(true);

    // Active Filter State
    const [activeGroup, setActiveGroup] = useState<string>("ALL");
    const [activeCategory, setActiveCategory] = useState<string>("ALL");
    const [selectedRegion, setSelectedRegion] = useState<string>("ALL");

    const activeInfoWindow = useRef<any>(null);
    const markersRef = useRef<any[]>([]);

    useEffect(() => {
        if (!mapContainer.current) return;

        const initializeMap = () => {
            if (!window.kakao || !window.kakao.maps) {
                return false;
            }

            const { kakao } = window;
            kakao.maps.load(() => {
                const options = {
                    center: new kakao.maps.LatLng(35.2383, 128.6925),
                    level: 11,
                };

                const map = new kakao.maps.Map(mapContainer.current, options);
                setMapInstance(map);

                const zoomControl = new kakao.maps.ZoomControl();
                map.addControl(zoomControl, kakao.maps.ControlPosition.RIGHT);
                const mapTypeControl = new kakao.maps.MapTypeControl();
                map.addControl(mapTypeControl, kakao.maps.ControlPosition.TOPRIGHT);

                Promise.all([
                    fetch('/data/fire_stations.json').then(res => res.json()),
                    fetch('/data/institution_profiles.json').then(res => res.json()),
                    fetch('/data/public_admin.json').then(res => res.json()),
                    fetch('/data/specialized.json').then(res => res.json()),
                    fetch('/data/emergency_hubs.json').then(res => res.json()),
                    fetch('/data/regional_welfare.json').then(res => res.json()),
                    fetch('/data/private_orgs.json').then(res => res.json())
                ]).then(([fireData, profileData, publicData, specializedData, emergencyData, regionalData, privateData]) => {
                    const processData = (data: any[], defaultCat: string, group: string) =>
                        data.map(item => ({ ...item, category: item.category || defaultCat, group }));

                    const profileFacilities = profileData.map((p: any) => ({
                        name: p.name,
                        address: p.address || '',
                        phone: p.contact?.mainPhone || '',
                        mainContact: p.contact?.phone || '',
                        region: p.region || '',
                        category: "수행기관",
                        group: "performer",
                        lat: p.lat,
                        lng: p.lng,
                    }));

                    const allData = [
                        ...processData(fireData, "소방서", "public"),
                        ...processData(publicData, "보건소", "public"),
                        ...processData(specializedData, "의료기관", "specialized"),
                        ...profileFacilities,
                        ...processData(emergencyData, "응급안전", "public"),
                        ...processData(regionalData, "노인복지관", "community"),
                        ...processData(privateData, "자원봉사", "community")
                    ];

                    const finalData = allData.map(item => {
                        let grp = "public";
                        if (["시군구청", "소방서", "경찰서", "보건소", "행정복지센터", "응급안전"].includes(item.category)) grp = "public";
                        else if (["정신건강", "노인보호", "의료기관"].includes(item.category)) grp = "specialized";
                        else if (["종합복지관", "노인복지관", "장애인복지관", "자원봉사"].includes(item.category)) grp = "community";
                        else if (["수행기관"].includes(item.category)) grp = "performer";
                        return { ...item, group: grp };
                    });

                    setFacilities(finalData);
                    setFilteredFacilities(finalData);
                    setLoading(false);
                }).catch(err => {
                    console.error("Failed to load data:", err);
                    setLoading(false);
                });
            });
            return true;
        };

        if (!initializeMap()) {
            const interval = setInterval(() => {
                if (initializeMap()) clearInterval(interval);
            }, 100);
            return () => clearInterval(interval);
        }
    }, []);

    // Filter Logic
    useEffect(() => {
        let result = facilities;

        // 1. Group Filter
        if (activeGroup !== "ALL") {
            result = result.filter(f => f.group === activeGroup);

            // 2. Category Filter
            if (activeCategory !== "ALL") {
                result = result.filter(f => f.category === activeCategory);
            }
        }

        // 3. Region Filter (Only apply if a region is selected)
        if (selectedRegion !== "ALL") {
            result = result.filter(f => f.address.includes(selectedRegion) || (f.region && f.region.includes(selectedRegion)));
        }

        setFilteredFacilities(result);
    }, [activeGroup, activeCategory, selectedRegion, facilities]);

    // Handle Group Click
    const handleGroupClick = (groupId: string) => {
        if (activeGroup === groupId) {
            setActiveGroup("ALL");
            setActiveCategory("ALL");
            setSelectedRegion("ALL");
        } else {
            setActiveGroup(groupId);
            setActiveCategory("ALL");
            setSelectedRegion("ALL");
        }
    };

    // Calculate Regions (memoized conceptually)
    const regions = Array.from(new Set(facilities.map(f => {
        const parts = f.address.split(' ');
        if (parts.length > 1) {
            if (parts[1].endsWith("시") || parts[1].endsWith("군")) return parts[1];
        }
        return "";
    }))).filter(r => r).sort();

    // Marker Rendering (using pre-computed lat/lng from data files)
    useEffect(() => {
        if (!mapInstance || !window.kakao) return;
        const { kakao } = window;

        // Clear markers
        markersRef.current.forEach(marker => marker.setMap(null));
        markersRef.current = [];

        filteredFacilities.forEach((facility) => {
            if (!facility.lat || !facility.lng) return;

            const coords = new kakao.maps.LatLng(facility.lat, facility.lng);

            const marker = new kakao.maps.Marker({
                map: mapInstance,
                position: coords,
                title: facility.name
            });

            markersRef.current.push(marker);

            const groupInfo = CATEGORY_GROUPS.find(g => g.id === facility.group);
            const color = groupInfo ? groupInfo.color : "#000";

            const contactHtml = facility.mainContact
                ? `<div style="color:#555; margin-top:4px; font-weight:600;">메인연락처: ${facility.mainContact}</div>`
                : `<div style="color:#888; margin-top:4px;">${facility.phone || '-'}</div>`;

            const iwContent = `<div style="padding:10px; font-size:12px; color:black; min-width:180px; border-radius:8px;">
                <span style="color:${color}; font-weight:800; font-size:11px; border:1px solid ${color}; padding:2px 6px; border-radius:12px;">${facility.category}</span>
                <div style="font-weight:bold; font-size:14px; margin-top:6px; margin-bottom:4px;">${facility.name}</div>
                <div style="color:#666; font-size:12px;">${facility.address}</div>
                ${contactHtml}
            </div>`;

            const infowindow = new kakao.maps.InfoWindow({
                content: iwContent,
                removable: true
            });

            kakao.maps.event.addListener(marker, 'click', function () {
                if (activeInfoWindow.current) {
                    activeInfoWindow.current.close();
                }
                infowindow.open(mapInstance, marker);
                activeInfoWindow.current = infowindow;
            });
        });

    }, [filteredFacilities, mapInstance]);

    return (
        <div className="w-full relative font-sans" style={{ height: 'calc(100vh - 48px)' }}>
            <div ref={mapContainer} className="w-full h-full" />

            {/* Legend / Filter UI */}
            <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-20 flex flex-col gap-3 items-center w-full max-w-4xl px-4 pointer-events-none">

                {/* 1. Main Groups */}
                <div className="flex gap-2 pointer-events-auto bg-white/95 backdrop-blur-md p-2 rounded-full shadow-xl border border-gray-100/50">
                    <button
                        onClick={() => { setActiveGroup("ALL"); setActiveCategory("ALL"); setSelectedRegion("ALL"); }}
                        className={`px-5 py-2 rounded-full text-sm font-bold transition-all ${activeGroup === "ALL"
                            ? "bg-gray-800 text-white shadow-lg scale-105"
                            : "text-gray-500 hover:bg-gray-100"
                            }`}
                    >
                        전체
                    </button>
                    {CATEGORY_GROUPS.map(group => (
                        <button
                            key={group.id}
                            onClick={() => handleGroupClick(group.id)}
                            className={`px-4 py-2 rounded-full text-sm font-bold transition-all flex items-center gap-2 ${activeGroup === group.id
                                ? "text-white shadow-lg transform scale-105"
                                : "text-gray-600 hover:bg-gray-100"
                                }`}
                            style={{
                                backgroundColor: activeGroup === group.id ? group.color : 'transparent',
                            }}
                        >
                            {activeGroup !== group.id && (
                                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: group.color }}></span>
                            )}
                            {group.label}
                        </button>
                    ))}
                </div>

                {/* 2. Sub-categories */}
                {activeGroup !== "ALL" && (
                    <div className="flex flex-wrap justify-center gap-2 pointer-events-auto animate-in slide-in-from-top-2 fade-in duration-300">
                        {CATEGORY_GROUPS.find(g => g.id === activeGroup)?.categories.map(cat => (
                            <button
                                key={cat}
                                onClick={() => setActiveCategory(activeCategory === cat ? "ALL" : cat)}
                                className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-all shadow-sm border ${activeCategory === cat
                                    ? "bg-white text-blue-600 border-blue-400 ring-2 ring-blue-100 shadow-md"
                                    : "bg-white/90 text-gray-500 border-gray-200 hover:bg-white hover:text-gray-800"
                                    }`}
                            >
                                {cat}
                            </button>
                        ))}
                    </div>
                )}

                {/* 3. Region Filter (Visible when Public or Performer group is active) */}
                {(activeGroup === "public" || activeGroup === "performer") && (
                    <div className="pointer-events-auto mt-1 animate-in slide-in-from-top-1 fade-in duration-300">
                        <select
                            aria-label="Filter by region"
                            value={selectedRegion}
                            onChange={(e) => setSelectedRegion(e.target.value)}
                            className="bg-white/95 backdrop-blur-sm border border-gray-200 text-gray-700 text-sm rounded-full focus:ring-blue-500 focus:border-blue-500 block p-2 px-4 shadow-lg cursor-pointer hover:bg-gray-50 transition-colors"
                        >
                            <option value="ALL">📍 모든 지역 (시/군 선택)</option>
                            {regions.map(region => (
                                <option key={region} value={region}>{region}</option>
                            ))}
                        </select>
                    </div>
                )}
            </div>

            {/* Stats Panel */}
            <div className="absolute top-6 left-6 z-10 bg-white/90 backdrop-blur-md p-5 rounded-2xl shadow-2xl border border-gray-100 min-w-[240px] transition-all hover:scale-105">
                <h1 className="font-bold text-xl text-gray-900 mb-3 tracking-tight">경상남도 복지자원</h1>
                {loading ? (
                    <p className="text-sm text-gray-400 animate-pulse font-medium">데이터 로딩 중...</p>
                ) : (
                    <div className="space-y-3">
                        <div className="flex justify-between items-center pb-3 border-b border-gray-100">
                            <span className="text-sm text-gray-500 font-medium">현재 표시 자원</span>
                            <span className="font-extrabold text-blue-600 text-2xl">{filteredFacilities.length}</span>
                        </div>
                        <div className="text-xs text-gray-500 space-y-1.5">
                            <p className="flex justify-between">
                                <span>선택 그룹</span>
                                <span className="font-bold text-gray-800">{
                                    activeGroup === "ALL" ? "전체 보기" : CATEGORY_GROUPS.find(g => g.id === activeGroup)?.label
                                }</span>
                            </p>
                            {activeGroup !== "ALL" && (
                                <p className="flex justify-between">
                                    <span>상세 분류</span>
                                    <span className="font-bold text-gray-800">{
                                        activeCategory === "ALL" ? "전체" : activeCategory
                                    }</span>
                                </p>
                            )}
                            {selectedRegion !== "ALL" && (
                                <p className="flex justify-between">
                                    <span>지역 필터</span>
                                    <span className="font-bold text-blue-600">{selectedRegion}</span>
                                </p>
                            )}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}
