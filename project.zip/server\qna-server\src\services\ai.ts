import Anthropic from "@anthropic-ai/sdk";
import type { Question, OfficialDocument } from "../types";

let client: Anthropic | null = null;

function getClient(): Anthropic | null {
  if (!process.env.ANTHROPIC_API_KEY) return null;
  if (!client) {
    client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  }
  return client;
}

function buildSystemPrompt(
  relatedDoc: OfficialDocument | null,
  similarQAs: Question[]
): string {
  let prompt = `당신은 경상남도 광역지원기관의 공문 Q&A 담당 AI 어시스턴트입니다.
사회복지사들의 질문에 대해 공문 원문을 참조하여 정확하고 친절한 답변 초안을 작성합니다.

답변 작성 시 주의사항:
- 공문 원문에 근거한 답변만 작성하세요
- 원문에 없는 내용은 "해당 내용은 공문에 명시되어 있지 않습니다"라고 안내하세요
- 답변은 마크다운 형식으로 구조화해주세요
- 관련 조항이나 항목을 구체적으로 인용하세요
- 추가 확인이 필요한 사항은 명시해주세요
`;

  if (relatedDoc) {
    prompt += `\n## 관련 공문 정보
- 공문번호: ${relatedDoc.documentNumber}
- 제목: ${relatedDoc.title}

### 공문 원문 내용:
${relatedDoc.content}
`;
  }

  if (similarQAs.length > 0) {
    prompt += `\n## 기존 유사 Q&A 이력 (참고용)\n`;
    for (const qa of similarQAs.slice(0, 3)) {
      prompt += `\n### Q: ${qa.title}\n${qa.content}\n\n### A:\n${qa.finalAnswer || qa.aiDraftAnswer || "(미답변)"}\n`;
    }
  }

  return prompt;
}

export async function generateAIDraft(
  question: Question,
  relatedDoc: OfficialDocument | null,
  similarQAs: Question[]
): Promise<string> {
  const anthropic = getClient();

  if (!anthropic) {
    // Mock response when API key is not configured
    const mockAnswers: Record<string, string> = {
      사업지침: `공문 원문을 검토한 결과, 질문하신 내용에 대해 다음과 같이 안내드립니다.

**주요 답변 내용:**
1. 해당 사업지침에 따르면, 관련 규정이 적용됩니다
2. 세부 사항은 사업안내서를 참고해주세요
3. 추가 문의사항이 있으시면 광역지원기관으로 연락 부탁드립니다

> 이 답변은 AI가 자동 생성한 초안입니다. 관리자 검토 후 최종 답변이 전달됩니다.`,
      행정절차: `행정절차 관련 문의에 대해 안내드립니다.

**처리 절차:**
1. 해당 서류를 준비하여 제출합니다
2. 담당부서에서 검토 후 결과를 통보합니다
3. 처리 기간은 통상 7~14일 소요됩니다

> 이 답변은 AI가 자동 생성한 초안입니다. 관리자 검토 후 최종 답변이 전달됩니다.`,
    };
    return mockAnswers[question.category] || mockAnswers["사업지침"];
  }

  const systemPrompt = buildSystemPrompt(relatedDoc, similarQAs);
  const userMessage = `## 질문
**제목**: ${question.title}
**카테고리**: ${question.category}
**기관**: ${question.authorOrgName}

**질문 내용**:
${question.content}

위 질문에 대한 답변 초안을 작성해주세요.`;

  const response = await anthropic.messages.create({
    model: "claude-sonnet-4-5-20250929",
    max_tokens: 2048,
    system: systemPrompt,
    messages: [{ role: "user", content: userMessage }],
  });

  const textBlock = response.content.find((b) => b.type === "text");
  if (!textBlock || textBlock.type !== "text") {
    throw new Error("AI 응답이 비어있습니다");
  }

  return textBlock.text;
}
