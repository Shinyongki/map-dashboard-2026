import { useState } from "react";
import {
    MessageSquareText,
    Plus,
    LogOut,
    Shield,
    FileText,
    LayoutList,
} from "lucide-react";
import { useAuth } from "@/features/qna/hooks/useAuth";
import { useQuestions } from "@/features/qna/hooks/useQuestions";
import { useDocuments } from "@/features/qna/hooks/useDocuments";
import type { Question, QuestionStatus } from "@/features/qna/lib/types";
import LoginForm from "@/features/qna/components/LoginForm";
import QuestionList from "@/features/qna/components/QuestionList";
import QuestionForm from "@/features/qna/components/QuestionForm";
import QuestionDetail from "@/features/qna/components/QuestionDetail";
import AdminPanel from "@/features/qna/components/AdminPanel";
import DocumentManager from "@/features/qna/components/DocumentManager";

type UserView = "list" | "form" | "detail";
type AdminTab = "questions" | "documents";

export default function QnADashboard() {
    const { session, login, logout, isAdmin } = useAuth();
    const {
        questions,
        loading,
        submitQuestion,
        approveAnswer,
        closeQuestion,
        removeQuestion,
        refresh,
    } = useQuestions();
    const {
        documents,
        loading: docsLoading,
        uploading,
        upload,
        remove: removeDoc,
    } = useDocuments();

    // User view state
    const [userView, setUserView] = useState<UserView>("list");
    const [selectedQuestion, setSelectedQuestion] = useState<Question | null>(
        null
    );
    const [statusFilter, setStatusFilter] = useState<QuestionStatus | "all">(
        "all"
    );
    const [searchQuery, setSearchQuery] = useState("");

    // Admin tab state
    const [adminTab, setAdminTab] = useState<AdminTab>("questions");

    if (!session) {
        return (
            <div className="max-w-7xl mx-auto px-4 py-8">
                <LoginForm onLogin={login} />
            </div>
        );
    }

    const handleSelectQuestion = (q: Question) => {
        setSelectedQuestion(q);
        setUserView("detail");
    };

    const handleSubmitQuestion = async (
        data: Parameters<typeof submitQuestion>[0]
    ) => {
        await submitQuestion(data);
        setUserView("list");
    };

    const getRelatedDoc = (q: Question) =>
        q.relatedDocumentId
            ? documents.find((d) => d.id === q.relatedDocumentId) ?? null
            : null;

    return (
        <div className="max-w-7xl mx-auto px-4 py-6">
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                    <div className="flex items-center justify-center w-10 h-10 bg-emerald-100 rounded-lg">
                        <MessageSquareText className="h-5 w-5 text-emerald-600" />
                    </div>
                    <div>
                        <h1 className="text-lg font-bold text-gray-900">공문 Q&A</h1>
                        <p className="text-xs text-gray-500">
                            {session.orgName} · {session.name}
                            {isAdmin && (
                                <span className="ml-1 inline-flex items-center gap-0.5 text-emerald-600 font-medium">
                                    <Shield className="h-3 w-3" /> 관리자
                                </span>
                            )}
                        </p>
                    </div>
                </div>

                <div className="flex items-center gap-2">
                    {!isAdmin && userView === "list" && (
                        <button
                            onClick={() => setUserView("form")}
                            className="flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-medium"
                        >
                            <Plus className="h-4 w-4" />
                            질문하기
                        </button>
                    )}
                    <button
                        onClick={logout}
                        className="flex items-center gap-1 px-3 py-1.5 border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50"
                    >
                        <LogOut className="h-4 w-4" />
                        로그아웃
                    </button>
                </div>
            </div>

            {/* Admin view */}
            {isAdmin ? (
                <div>
                    {/* Admin tabs */}
                    <div className="flex gap-1 mb-4">
                        <button
                            onClick={() => setAdminTab("questions")}
                            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${adminTab === "questions"
                                    ? "bg-emerald-100 text-emerald-700"
                                    : "bg-gray-100 text-gray-500 hover:bg-gray-200"
                                }`}
                        >
                            <LayoutList className="h-4 w-4" />
                            질문 관리
                        </button>
                        <button
                            onClick={() => setAdminTab("documents")}
                            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${adminTab === "documents"
                                    ? "bg-emerald-100 text-emerald-700"
                                    : "bg-gray-100 text-gray-500 hover:bg-gray-200"
                                }`}
                        >
                            <FileText className="h-4 w-4" />
                            공문 관리
                        </button>
                    </div>

                    {adminTab === "questions" ? (
                        <AdminPanel
                            questions={questions}
                            documents={documents}
                            loading={loading}
                            adminName={session.name}
                            onApprove={approveAnswer}
                            onClose={closeQuestion}
                            onDelete={removeQuestion}
                        />
                    ) : (
                        <DocumentManager
                            documents={documents}
                            loading={docsLoading}
                            uploading={uploading}
                            onUpload={upload}
                            onDelete={removeDoc}
                            uploadedBy={session.name}
                        />
                    )}
                </div>
            ) : (
                /* User view */
                <div>
                    {userView === "form" ? (
                        <QuestionForm
                            documents={documents}
                            authorName={session.name}
                            authorOrg={session.orgCode}
                            authorOrgName={session.orgName}
                            onSubmit={handleSubmitQuestion}
                            onCancel={() => setUserView("list")}
                        />
                    ) : userView === "detail" && selectedQuestion ? (
                        <QuestionDetail
                            question={selectedQuestion}
                            relatedDocument={getRelatedDoc(selectedQuestion)}
                            isAdmin={false}
                            onBack={() => {
                                setUserView("list");
                                setSelectedQuestion(null);
                            }}
                        />
                    ) : (
                        <QuestionList
                            questions={questions}
                            loading={loading}
                            onSelect={handleSelectQuestion}
                            selectedId={selectedQuestion?.id}
                            statusFilter={statusFilter}
                            onStatusFilterChange={setStatusFilter}
                            searchQuery={searchQuery}
                            onSearchChange={setSearchQuery}
                        />
                    )}
                </div>
            )}
        </div>
    );
}
