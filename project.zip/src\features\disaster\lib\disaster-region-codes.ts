// 기후대응 모듈의 지역 코드를 재사용
export { CLIMATE_REGION_CODES, GYEONGNAM_REGIONS } from "@/features/climate/lib/climate-region-codes";
